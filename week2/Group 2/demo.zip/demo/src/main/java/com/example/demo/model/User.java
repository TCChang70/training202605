package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "user")
@Data
public class User {
    private Integer user_id;
    private String username_chinese;
    private String username_english;
    private String user_email;
    private String user_password;
    private String user_birthday;
    private String user_gender;
    private String username_nationality;
    private String username_phone;
    private String user_passport;
    private String user_emergencyContactePerson;
    private String user_emergencyContactPhone;
}
