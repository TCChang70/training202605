package restaurant;

import javax.swing.*;
import java.awt.*;

public class RegisterWin extends JFrame {
    public RegisterWin() {
        setTitle("餐廳系統 - 帳號註冊");
        setSize(350, 450);
        setLocationRelativeTo(null);
        // 設定 7 列 2 欄 (帳號、密碼、姓名、電話、Email、按鈕列)
        setLayout(new GridLayout(7, 2, 10, 10));

        // 建立輸入欄位
        JTextField userField = new JTextField();
        JPasswordField passField = new JPasswordField();
        JTextField nameField = new JTextField();
        JTextField phoneField = new JTextField();
        JTextField emailField = new JTextField();

        // 加入介面
        add(new JLabel("  帳號:")); add(userField);
        add(new JLabel("  密碼:")); add(passField);
        add(new JLabel("  姓名:")); add(nameField);
        add(new JLabel("  電話:")); add(phoneField);
        add(new JLabel("  Email:")); add(emailField);

        JButton btnSubmit = new JButton("提交註冊");
        JButton btnCancel = new JButton("返回");
        add(btnSubmit);
        add(btnCancel);

        // 註冊按鈕邏輯
        btnSubmit.addActionListener(e -> {
            String user = userField.getText();
            String pass = new String(passField.getPassword());
            String name = nameField.getText();
            String phone = phoneField.getText();
            String email = emailField.getText();

            if(user.isEmpty() || pass.isEmpty()) {
                JOptionPane.showMessageDialog(this, "帳號密碼不能為空！");
                return;
            }

            UserDao dao = new UserDao();
            // 呼叫你更新後的 UserDao.register 方法
            boolean success = dao.register(user, pass, "CUSTOMER", name, phone, email);

            if (success) {
                JOptionPane.showMessageDialog(this, "註冊成功！請登入");
                dispose(); // 關閉註冊視窗
            } else {
                JOptionPane.showMessageDialog(this, "註冊失敗，帳號可能重複");
            }
        });

        // 返回按鈕邏輯
        btnCancel.addActionListener(e -> dispose());
    }
}
