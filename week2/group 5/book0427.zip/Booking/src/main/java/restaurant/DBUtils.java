package restaurant;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtils {
    private static final String URL = "jdbc:mysql://localhost:3306/booktable?serverTimezone=UTC";
    private static final String USER = "root"; // 你的帳號
    private static final String PWD = "1234"; // 你的密碼

    public static Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(URL, USER, PWD);
    }
}
