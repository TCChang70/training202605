package restaurant;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;

public class Admin extends JFrame {
    private JLabel lblStatus, lblTotalToday;
    private JTable table;
    private DefaultTableModel tableModel;

    public Admin() {
        // --- 1. 視窗基礎設定 ---
        setTitle("餐廳後台管理系統");
        setSize(950, 650); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(15, 15));

        // --- 2. 上方區域：狀態與控制 ---
        JPanel topPanel = new JPanel(new GridLayout(2, 1, 10, 10));
        topPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 0, 15));

        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        lblStatus = new JLabel("目前狀態: 讀取中...");
        lblStatus.setFont(new Font("Microsoft JhengHei", Font.BOLD, 15));

        JButton btnOpen = new JButton("開啟訂位");
        btnOpen.setBackground(new Color(40, 167, 69));
        btnOpen.setForeground(Color.WHITE);

        JButton btnClose = new JButton("關閉訂位");
        btnClose.setBackground(new Color(220, 53, 69));
        btnClose.setForeground(Color.WHITE);

        controlPanel.add(lblStatus);
        controlPanel.add(btnOpen);
        controlPanel.add(btnClose);

        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        lblTotalToday = new JLabel("今日總人數: 0 人");
        lblTotalToday.setFont(new Font("Microsoft JhengHei", Font.BOLD, 15));
        JButton btnRefresh = new JButton("重新整理資料");

        infoPanel.add(lblTotalToday);
        infoPanel.add(btnRefresh);

        topPanel.add(controlPanel);
        topPanel.add(infoPanel);
        add(topPanel, BorderLayout.NORTH);

        // --- 3. 中間區域：預約清單 ---
        tableModel = new DefaultTableModel(new String[]{"ID", "顧客帳號", "日期", "時間", "人數"}, 0);
        table = new JTable(tableModel);
        table.setRowHeight(35);
        table.getTableHeader().setFont(new Font("Microsoft JhengHei", Font.BOLD, 14));
        table.setFont(new Font("Microsoft JhengHei", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(0, 15, 0, 15));
        add(scrollPane, BorderLayout.CENTER);

        // --- 4. 下方區域：功能按鈕 ---
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 15));

        JButton btnManualAdd = new JButton("手動新增");
        btnManualAdd.setBackground(new Color(0, 123, 255));
        btnManualAdd.setForeground(Color.WHITE);

        JButton btnAdd = new JButton("人數 +1");
        JButton btnSub = new JButton("人數 -1");

        JButton btnDelete = new JButton("刪除預約");
        btnDelete.setBackground(new Color(108, 117, 125));
        btnDelete.setForeground(Color.WHITE);

        // 新增：匯出按鈕
        JButton btnExport = new JButton("匯出 Excel (CSV)");
        btnExport.setBackground(new Color(25, 135, 84)); // 深綠色
        btnExport.setForeground(Color.WHITE);

        JButton btnLogout = new JButton("登出系統");

        bottomPanel.add(btnManualAdd);
        bottomPanel.add(btnAdd);
        bottomPanel.add(btnSub);
        bottomPanel.add(btnDelete);
        bottomPanel.add(btnExport); // 加入畫面
        bottomPanel.add(btnLogout);
        add(bottomPanel, BorderLayout.SOUTH);

        // --- 5. 事件監聽 ---
        btnOpen.addActionListener(e -> updateSystemStatus("OPEN"));
        btnClose.addActionListener(e -> updateSystemStatus("CLOSED"));
        btnRefresh.addActionListener(e -> refreshData());
        btnLogout.addActionListener(e -> {
            dispose();
            new LoginWin().setVisible(true);
        });
        btnAdd.addActionListener(e -> adjustGuest(1));
        btnSub.addActionListener(e -> adjustGuest(-1));
        btnDelete.addActionListener(e -> deleteBooking());
        btnManualAdd.addActionListener(e -> showManualAddDialog());
        
        // 匯出功能監聽器
        btnExport.addActionListener(e -> exportToCSV());

        refreshData();
    }

    // 匯出 Excel (CSV) 的邏輯
    private void exportToCSV() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "目前沒有資料可以匯出！");
            return;
        }

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("請選擇儲存位置");
        fileChooser.setSelectedFile(new File("餐廳預約報表.csv"));

        int userSelection = fileChooser.showSaveDialog(this);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            
            // 強制加上 .csv 副檔名
            String filePath = fileToSave.getAbsolutePath();
            if (!filePath.toLowerCase().endsWith(".csv")) {
                fileToSave = new File(filePath + ".csv");
            }

            try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileToSave))) {
                // 寫入 UTF-8 BOM (避免 Excel 開啟時中文變亂碼)
                bw.write('\ufeff');

                // 寫入標題列
                for (int i = 0; i < tableModel.getColumnCount(); i++) {
                    bw.write(tableModel.getColumnName(i));
                    if (i < tableModel.getColumnCount() - 1) bw.write(",");
                }
                bw.newLine();

                // 寫入每一行資料
                for (int row = 0; row < tableModel.getRowCount(); row++) {
                    for (int col = 0; col < tableModel.getColumnCount(); col++) {
                        Object cellValue = tableModel.getValueAt(row, col);
                        bw.write(cellValue != null ? cellValue.toString() : "");
                        if (col < tableModel.getColumnCount() - 1) bw.write(",");
                    }
                    bw.newLine();
                }

                JOptionPane.showMessageDialog(this, "檔案匯出成功！\n路徑: " + fileToSave.getAbsolutePath());
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "匯出發生錯誤: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
    }

    private void showManualAddDialog() {
        JTextField userField = new JTextField();
        JComboBox<String> yearBox = new JComboBox<>(new String[]{"2026", "2027", "2028"});
        JComboBox<String> monthBox = new JComboBox<>(new String[]{"01","02","03","04","05","06","07","08","09","10","11","12"});
        JComboBox<String> dayBox = new JComboBox<>();
        for(int i=1; i<=31; i++) dayBox.addItem(String.format("%02d", i));

        JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        datePanel.add(yearBox); datePanel.add(new JLabel("年 "));
        datePanel.add(monthBox); datePanel.add(new JLabel("月 "));
        datePanel.add(dayBox); datePanel.add(new JLabel("日"));

        JComboBox<String> timeBox = new JComboBox<>(new String[]{
            "11:00", "11:30", "12:00", "12:30", "13:00", "13:30",
            "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30"
        });
        JSpinner guestSpinner = new JSpinner(new SpinnerNumberModel(2, 1, 50, 1));

        Object[] message = {
            "顧客帳號:", userField,
            "選擇日期:", datePanel,
            "選擇時間:", timeBox,
            "人數:", guestSpinner
        };

        int option = JOptionPane.showConfirmDialog(null, message, "管理員手動預約", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String fullDate = yearBox.getSelectedItem() + "-" + monthBox.getSelectedItem() + "-" + dayBox.getSelectedItem();
            String fullTime = timeBox.getSelectedItem().toString() + ":00";
            String username = userField.getText();
            int guests = (int) guestSpinner.getValue();

            if (username.isEmpty()) {
                JOptionPane.showMessageDialog(this, "帳號不能為空！");
                return;
            }

            String sql = "INSERT INTO bookings (username, booking_date, booking_time, guests) VALUES (?, ?, ?, ?)";
            try (Connection conn = DBUtils.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, username);
                pstmt.setString(2, fullDate);
                pstmt.setString(3, fullTime);
                pstmt.setInt(4, guests);
                pstmt.executeUpdate();
                refreshData();
                JOptionPane.showMessageDialog(this, "新增成功！");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "新增失敗：" + ex.getMessage());
            }
        }
    }

    private void deleteBooking() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "請先選擇一筆要刪除的預約！");
            return;
        }
        int id = (int) tableModel.getValueAt(row, 0);
        int response = JOptionPane.showConfirmDialog(this, "確定要刪除 ID: " + id + " 嗎？", "確認", JOptionPane.YES_NO_OPTION);
        if (response == JOptionPane.YES_OPTION) {
            String sql = "DELETE FROM bookings WHERE id = ?";
            try (Connection conn = DBUtils.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, id);
                pstmt.executeUpdate();
                refreshData();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void updateSystemStatus(String status) {
        String sql = "UPDATE system_settings SET config_value = ? WHERE config_key = 'is_booking_open'";
        try (Connection conn = DBUtils.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, status);
            pstmt.executeUpdate();
            refreshData();
            JOptionPane.showMessageDialog(this, "系統狀態已更新為: " + status);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void refreshData() {
        try (Connection conn = DBUtils.getConnection()) {
            Statement stmt = conn.createStatement();
            ResultSet rsStatus = stmt.executeQuery("SELECT config_value FROM system_settings WHERE config_key = 'is_booking_open'");
            if (rsStatus.next()) lblStatus.setText("目前狀態: " + rsStatus.getString("config_value"));

            ResultSet rsSum = stmt.executeQuery("SELECT SUM(guests) FROM bookings WHERE booking_date = CURDATE()");
            if (rsSum.next()) lblTotalToday.setText("今日預約總人數: " + rsSum.getInt(1) + " 人");

            ResultSet rsList = stmt.executeQuery("SELECT id, username, booking_date, booking_time, guests FROM bookings ORDER BY booking_date DESC, booking_time DESC");
            tableModel.setRowCount(0);
            while (rsList.next()) {
                tableModel.addRow(new Object[]{
                    rsList.getInt("id"),
                    rsList.getString("username"),
                    rsList.getString("booking_date"),
                    rsList.getString("booking_time"),
                    rsList.getInt("guests")
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void adjustGuest(int amount) {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "請先選擇一筆預約！");
            return;
        }
        int id = (int) tableModel.getValueAt(row, 0);
        int currentGuests = (int) tableModel.getValueAt(row, 4);
        int newGuests = currentGuests + amount;
        if (newGuests < 1) return;

        String sql = "UPDATE bookings SET guests = ? WHERE id = ?";
        try (Connection conn = DBUtils.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, newGuests);
            pstmt.setInt(2, id);
            pstmt.executeUpdate();
            refreshData();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


