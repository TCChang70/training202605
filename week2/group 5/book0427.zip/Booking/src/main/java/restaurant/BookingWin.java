package restaurant;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import restaurant.JwtUtils;

public class BookingWin extends JFrame {
    private String currentUsername;
    private String userToken;
    
    // 選單元件
    private JComboBox<String> yearBox, monthBox, dayBox, timeBox;

    public BookingWin(String username, String token) {
        this.currentUsername = username;
        this.userToken = token;

        // --- 1. 視窗基礎設定 ---
        setTitle("餐廳訂位系統 - 歡迎 " + username);
        setSize(480, 500); // 調大視窗高度
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // 使用 BorderLayout 搭配內邊距
        JPanel mainPanel = new JPanel(new GridLayout(7, 2, 15, 15));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));

        // --- 2. 建立元件並美化 ---
        Font labelFont = new Font("Microsoft JhengHei", Font.BOLD, 14);

        // 日期選擇
        JLabel lblDate = new JLabel("選擇預約日期:");
        lblDate.setFont(labelFont);
        JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        yearBox = new JComboBox<>(new String[]{"2026", "2027", "2028"});
        monthBox = new JComboBox<>(new String[]{"01","02","03","04","05","06","07","08","09","10","11","12"});
        dayBox = new JComboBox<>();
        for(int i=1; i<=31; i++) dayBox.addItem(String.format("%02d", i));
        
        datePanel.add(yearBox); datePanel.add(new JLabel("年"));
        datePanel.add(monthBox); datePanel.add(new JLabel("月"));
        datePanel.add(dayBox); datePanel.add(new JLabel("日"));

        // 時間與人數
        JLabel lblTime = new JLabel("選擇預約時間:");
        lblTime.setFont(labelFont);
        timeBox = new JComboBox<>(new String[]{
            "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", 
            "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30"
        });

        JLabel lblGuest = new JLabel("用餐人數:");
        lblGuest.setFont(labelFont);
        JSpinner guestSpinner = new JSpinner(new SpinnerNumberModel(2, 1, 20, 1));

        // 功能按鈕美化
        JButton btnSubmit = new JButton("確認訂位");
        btnSubmit.setBackground(new Color(0, 122, 204)); // 藍色
        btnSubmit.setForeground(Color.WHITE);
        btnSubmit.putClientProperty("JButton.buttonType", "roundRect");
        btnSubmit.setFont(new Font("Microsoft JhengHei", Font.BOLD, 14));

        JButton btnQuery = new JButton("查詢我的預約");
        btnQuery.putClientProperty("JButton.buttonType", "roundRect");

        JButton btnLogout = new JButton("登出系統");
        btnLogout.setBackground(new Color(108, 117, 125)); // 灰色
        btnLogout.setForeground(Color.WHITE);
        btnLogout.putClientProperty("JButton.buttonType", "roundRect");

        // --- 3. 加入面板 ---
        mainPanel.add(lblDate); mainPanel.add(datePanel);
        mainPanel.add(lblTime); mainPanel.add(timeBox);
        mainPanel.add(lblGuest); mainPanel.add(guestSpinner);
        mainPanel.add(new JLabel("")); mainPanel.add(btnSubmit);
        mainPanel.add(new JLabel("")); mainPanel.add(btnQuery);
        mainPanel.add(new JLabel("")); mainPanel.add(btnLogout);

        add(mainPanel);

        // --- 4. 事件監聽 (原邏輯不變) ---
        btnSubmit.addActionListener(e -> {
            try { 
                JwtUtils.parseToken(userToken); 
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "登入逾時，請重新登入", "逾時", JOptionPane.ERROR_MESSAGE);
                dispose(); 
                new LoginWin().setVisible(true); 
                return;
            }

            if (!Opentime()) {
                JOptionPane.showMessageDialog(null, "抱歉，目前管理員已關閉預約功能！", "暫停服務", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String fullDate = yearBox.getSelectedItem() + "-" + monthBox.getSelectedItem() + "-" + dayBox.getSelectedItem();
            String fullTime = timeBox.getSelectedItem().toString();
            saveBooking(fullDate, fullTime, (int) guestSpinner.getValue());
        });

        btnQuery.addActionListener(e -> showMyBookings());
        btnLogout.addActionListener(e -> { dispose(); new LoginWin().setVisible(true); });
    }

    private boolean Opentime() {
        String sql = "SELECT config_value FROM system_settings WHERE config_key = 'is_booking_open'";
        try (Connection conn = DBUtils.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return "OPEN".equalsIgnoreCase(rs.getString("config_value").trim());
            }
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }

    private void saveBooking(String date, String time, int guests) {
        String countSql = "SELECT COUNT(*) FROM bookings WHERE booking_date = ?";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement countPstmt = conn.prepareStatement(countSql)) {
            
            countPstmt.setString(1, date);
            ResultSet rs = countPstmt.executeQuery();
            if (rs.next() && rs.getInt(1) >= 10) {
                JOptionPane.showMessageDialog(this, "抱歉，" + date + " 已額滿 (限額 10 組)！", "額滿提示", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String insertSql = "INSERT INTO bookings (username, booking_date, booking_time, guests) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(insertSql)) {
                pstmt.setString(1, currentUsername);
                pstmt.setString(2, date);
                pstmt.setString(3, time + ":00");
                pstmt.setInt(4, guests);
                if (pstmt.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(this, "訂位成功！\n日期：" + date + "\n時間：" + time, "成功", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "訂位失敗：" + ex.getMessage());
        }
    }

    private void showMyBookings() {
        StringBuilder sb = new StringBuilder("您的預約紀錄：\n\n");
        String sql = "SELECT booking_date, booking_time, guests FROM bookings WHERE username = ? ORDER BY booking_date DESC";
        try (Connection conn = DBUtils.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, currentUsername);
            ResultSet rs = pstmt.executeQuery();
            boolean hasData = false;
            while (rs.next()) {
                hasData = true;
                sb.append(String.format("📅 %s   🕒 %s   👥 %d人\n", 
                    rs.getString("booking_date"), rs.getString("booking_time"), rs.getInt("guests")));
            }
            JOptionPane.showMessageDialog(this, hasData ? sb.toString() : "目前沒有預約紀錄。", "預約查詢", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) { ex.printStackTrace(); }
    }
}
