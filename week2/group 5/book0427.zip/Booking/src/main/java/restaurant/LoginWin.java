package restaurant;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import com.formdev.flatlaf.FlatDarkLaf; // 導入美化套件

public class LoginWin extends JFrame {

    private JTextField userField;
    private JPasswordField passField;
    private JButton btnLogin;
    private JButton btnRegister;

    public LoginWin() {
        // 1. 設定視窗與佈局
        setTitle("餐廳訂位系統 - 登入");
        setSize(400, 300); // 稍微調大一點，讓美化效果更明顯
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // 使用更精緻的邊距
        JPanel mainPanel = new JPanel(new GridLayout(4, 2, 15, 15));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        // 2. 建立元件並增加細節美化
        JLabel lblUser = new JLabel("帳號:");
        lblUser.setFont(new Font("Microsoft JhengHei", Font.BOLD, 14));
        userField = new JTextField();
        userField.putClientProperty("JTextField.placeholderText", "請輸入帳號");
        userField.putClientProperty("JTextField.showClearButton", true); // 增加清除按鈕

        JLabel lblPass = new JLabel("密碼:");
        lblPass.setFont(new Font("Microsoft JhengHei", Font.BOLD, 14));
        passField = new JPasswordField();
        passField.putClientProperty("JTextField.placeholderText", "請輸入密碼");
        passField.putClientProperty("JTextField.showRevealButton", true); // 增加顯示密碼眼睛

        btnLogin = new JButton("登入系統");
        // 美化按鈕：設為圓角與主色調藍色
        btnLogin.putClientProperty("JButton.buttonType", "roundRect");
        btnLogin.setBackground(new Color(0, 122, 204));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFont(new Font("Microsoft JhengHei", Font.BOLD, 14));

        btnRegister = new JButton("註冊帳號");
        btnRegister.putClientProperty("JButton.buttonType", "roundRect");

        // 3. 加入面板
        mainPanel.add(lblUser); mainPanel.add(userField);
        mainPanel.add(lblPass); mainPanel.add(passField);
        mainPanel.add(new JLabel("")); mainPanel.add(btnLogin);
        mainPanel.add(new JLabel("")); mainPanel.add(btnRegister);

        add(mainPanel);

        // --- 登入按鈕邏輯 ---
        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = userField.getText();
                String password = new String(passField.getPassword());

                UserDao userDao = new UserDao();
                String role = userDao.login(username, password);

                if (role != null) {
                    String token = JwtUtils.createToken(username);

                    if (role.equalsIgnoreCase("ADMIN")) {
                        JOptionPane.showMessageDialog(null, "管理員您好！");
                        Admin adminFrame = new Admin(); 
                        adminFrame.setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(null, "登入成功，前往訂位系統");
                        BookingWin bookingWin = new BookingWin(username, token);
                        bookingWin.setVisible(true);
                    }
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "帳號或密碼錯誤！", "登入失敗", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // --- 註冊按鈕邏輯 ---
        btnRegister.addActionListener(e -> {
            RegisterWin regWin = new RegisterWin();
            regWin.setVisible(true);
        });
    }

    public static void main(String[] args) {
        // 在啟動前套用深色主題
        try {
            FlatDarkLaf.setup();
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> new LoginWin().setVisible(true));
    }
}

