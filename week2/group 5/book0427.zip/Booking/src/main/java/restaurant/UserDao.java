package restaurant;

import java.sql.*;

public class UserDao {
    // 1. POST 用：註冊功能
    public boolean register(String username, String password, String role, String name, String phone, String email) {
        String sql = "INSERT INTO consumer (username, password, role, name, phone, email) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBUtils.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setString(3, role);
            pstmt.setString(4, name);
            pstmt.setString(5, phone);
            pstmt.setString(6, email);
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // 2. POST 用：登入驗證
    public String login(String username, String password) {
        String sql = "SELECT role FROM consumer WHERE username = ? AND password = ?";
        try (Connection conn = DBUtils.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) return rs.getString("role");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // 3. PUT 用：修改資料 (你提到的 sport/update 功能)
    public boolean update(String username, String name, String phone, String email) {
        String sql = "UPDATE consumer SET name=?, phone=?, email=? WHERE username=?";
        try (Connection conn = DBUtils.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, phone);
            pstmt.setString(3, email);
            pstmt.setString(4, username);
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // 4. DELETE 用：刪除帳號
    public boolean delete(String username) {
        String sql = "DELETE FROM consumer WHERE username=?";
        try (Connection conn = DBUtils.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}

