package restaurant;

import restaurant.JwtUtils;
import io.jsonwebtoken.Claims;

public class MainApp {
    public static void main(String[] args) {
        // 模擬登入成功，發放 token
        String token = JwtUtils.createToken("customer01");
        System.out.println("產生的 Token: " + token);

        // 模擬 2 小時內的請求驗證
        try {
            Claims claims = JwtUtils.parseToken(token);
            System.out.println("當前用戶: " + claims.getSubject());
            System.out.println("過期時間: " + claims.getExpiration());
        } catch (Exception e) {
            System.out.println("Token 無效或已超過 2 小時，請重新登入！");
        }
    }
}
