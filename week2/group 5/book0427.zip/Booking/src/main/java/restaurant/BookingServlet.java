package restaurant;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/api/booking")
public class BookingServlet extends HttpServlet {

    // 1. GET: 查詢紀錄 (OK)
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=UTF-8");
        String username = req.getParameter("username");
        String isAdmin = req.getParameter("adminQuery");

        StringBuilder json = new StringBuilder("[");
        String sql;
        
        if ("true".equals(isAdmin)) {
            sql = "SELECT username, booking_date, booking_time, guests FROM bookings ORDER BY booking_date DESC";
        } else {
            sql = "SELECT username, booking_date, booking_time, guests FROM bookings WHERE username = ? ORDER BY booking_date DESC";
        }

        try (Connection conn = DBUtils.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            if (!"true".equals(isAdmin)) {
                pstmt.setString(1, username);
            }
            
            ResultSet rs = pstmt.executeQuery();
            boolean first = true;
            while (rs.next()) {
                if (!first) json.append(",");
                json.append("{")
                    .append("\"username\":\"").append(rs.getString("username")).append("\",")
                    .append("\"date\":\"").append(rs.getString("booking_date")).append("\",")
                    .append("\"time\":\"").append(rs.getString("booking_time")).append("\",")
                    .append("\"guests\":").append(rs.getInt("guests"))
                    .append("}");
                first = false;
            }
            json.append("]");
            resp.getWriter().write(json.toString());
        } catch (Exception e) {
            e.printStackTrace();
            resp.setStatus(500);
            resp.getWriter().write("{\"status\":\"error\", \"message\":\"查詢失敗\"}");
        }
    }

    // 2. POST: 新增預約 (OK)
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json;charset=UTF-8");
        
        try {
            String username = req.getParameter("username");
            String date = req.getParameter("date");
            String time = req.getParameter("time");
            String guestsStr = req.getParameter("guests");

            if (username == null || date == null || time == null || guestsStr == null) {
                resp.getWriter().write("{\"status\":\"error\", \"message\":\"請填寫完整資料\"}");
                return;
            }

            int guests = Integer.parseInt(guestsStr);
            String sql = "INSERT INTO bookings (username, booking_date, booking_time, guests) VALUES (?, ?, ?, ?)";
            
            try (Connection conn = DBUtils.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, username);
                pstmt.setString(2, date);
                pstmt.setString(3, time.contains(":") ? time : time + ":00");
                pstmt.setInt(4, guests);
                pstmt.executeUpdate();
                resp.getWriter().write("{\"status\":\"success\", \"message\":\"訂位成功！\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.getWriter().write("{\"status\":\"error\", \"message\":\"伺服器錯誤\"}");
        }
    }

    // 3. PUT: 修改預約 (優化：增加參數防呆)
    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 設定編碼，確保接收到的參數不會亂碼
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json;charset=UTF-8");

        String username = req.getParameter("username");
        String date = req.getParameter("date");
        String guests = req.getParameter("guests");

        // 防呆檢查
        if (username == null || date == null || guests == null) {
            resp.getWriter().write("{\"status\":\"error\", \"message\":\"修改參數不足\"}");
            return;
        }

        String sql = "UPDATE bookings SET guests = ? WHERE username = ? AND booking_date = ?";
        try (Connection conn = DBUtils.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, Integer.parseInt(guests));
            pstmt.setString(2, username);
            pstmt.setString(3, date);
            
            int row = pstmt.executeUpdate();
            if(row > 0) {
                resp.getWriter().write("{\"status\":\"success\", \"message\":\"管理員修改成功！\"}");
            } else {
                resp.getWriter().write("{\"status\":\"error\", \"message\":\"找不到該紀錄\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.getWriter().write("{\"status\":\"error\", \"message\":\"修改時發生資料庫錯誤\"}");
        }
    }

    // 4. DELETE: 取消預約 (OK)
    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=UTF-8");
        String username = req.getParameter("username");
        String date = req.getParameter("date");

        if (username == null || date == null) {
            resp.getWriter().write("{\"status\":\"error\", \"message\":\"刪除參數不足\"}");
            return;
        }

        String sql = "DELETE FROM bookings WHERE username = ? AND booking_date = ?";
        try (Connection conn = DBUtils.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, date);
            
            int row = pstmt.executeUpdate();
            if(row > 0) {
                resp.getWriter().write("{\"status\":\"success\", \"message\":\"已成功取消預約\"}");
            } else {
                resp.getWriter().write("{\"status\":\"error\", \"message\":\"找不到該紀錄\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.getWriter().write("{\"status\":\"error\", \"message\":\"取消失敗\"}");
        }
    }
}
