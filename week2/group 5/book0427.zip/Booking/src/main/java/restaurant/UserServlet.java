package restaurant;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/api/user/*")
public class UserServlet extends HttpServlet {
    // 建立 UserDao 物件 (注意大小寫一致)
    private UserDao userDao = new UserDao();

    // GET: 查詢使用者 (簡單回應)
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=UTF-8");
        String username = req.getParameter("username");
        resp.getWriter().write("{\"status\":\"success\", \"message\":\"已查詢使用者: " + username + "\"}");
    }

    // POST: 登入與註冊
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json;charset=UTF-8");
        String pathInfo = req.getPathInfo();

        if ("/login".equals(pathInfo)) {
            String u = req.getParameter("username");
            String p = req.getParameter("password");
            String role = userDao.login(u, p);
            if (role != null) {
                resp.getWriter().write("{\"status\":\"success\", \"role\":\"" + role + "\"}");
            } else {
                resp.setStatus(401);
                resp.getWriter().write("{\"status\":\"error\", \"message\":\"帳號密碼錯誤\"}");
            }
        } else if ("/register".equals(pathInfo)) {
            boolean success = userDao.register(
                req.getParameter("username"), req.getParameter("password"),
                req.getParameter("role"), req.getParameter("name"),
                req.getParameter("phone"), req.getParameter("email")
            );
            resp.getWriter().write("{\"status\":\"" + (success ? "success" : "error") + "\"}");
        }
    }

    // PUT: 修改資料 (對應 update)
    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json;charset=UTF-8");
        boolean success = userDao.update(
            req.getParameter("username"), req.getParameter("name"),
            req.getParameter("phone"), req.getParameter("email")
        );
        resp.getWriter().write("{\"status\":\"" + (success ? "success" : "error") + "\"}");
    }

    // DELETE: 刪除帳號
    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=UTF-8");
        boolean success = userDao.delete(req.getParameter("username"));
        resp.getWriter().write("{\"status\":\"" + (success ? "success" : "error") + "\"}");
    }
}
